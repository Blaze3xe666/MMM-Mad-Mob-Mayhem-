package com.example.mmm;

import com.example.mmm.entity.MMMEntity;
import com.example.mmm.registry.MMMEntities;
import com.example.mmm.registry.MMMItems;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;

@Mod(MMMMod.MOD_ID)
public class MMMMod {
    public static final String MOD_ID = "mmm";

    public MMMMod(FMLJavaModLoadingContext context) {
        IEventBus modBus = context.getModEventBus();
        MMMEntities.ENTITY_TYPES.register(modBus);
        MMMItems.ITEMS.register(modBus);
        modBus.addListener(this::registerAttributes);
    }

    private void registerAttributes(EntityAttributeCreationEvent event) {
        event.put(MMMEntities.MMM_01.get(), MMMEntity.createAttributes().build());
    }
}

package com.example.mmm.registry;

import com.example.mmm.MMMMod;
import com.example.mmm.entity.MMMEntity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class MMMEntities {
    public static final DeferredRegister<EntityType<?>> ENTITY_TYPES =
            DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, MMMMod.MOD_ID);

    public static final RegistryObject<EntityType<MMMEntity>> MMM_01 = ENTITY_TYPES.register("mmm_01",
            () -> EntityType.Builder.of(MMMEntity::new, MobCategory.MONSTER)
                    .sized(0.6F, 1.95F)
                    .clientTrackingRange(8)
                    .build("mmm:mmm_01"));

    private MMMEntities() {}
}

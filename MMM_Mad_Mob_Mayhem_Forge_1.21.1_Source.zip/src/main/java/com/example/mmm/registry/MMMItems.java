package com.example.mmm.registry;

import com.example.mmm.MMMMod;
import net.minecraft.world.item.Item;
import net.minecraftforge.common.ForgeSpawnEggItem;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class MMMItems {
    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, MMMMod.MOD_ID);

    public static final RegistryObject<Item> MMM_SPAWN_EGG = ITEMS.register("mmm_spawn_egg",
            () -> new ForgeSpawnEggItem(MMMEntities.MMM_01, 0x24152F, 0xB54CFF, new Item.Properties()));

    private MMMItems() {}
}

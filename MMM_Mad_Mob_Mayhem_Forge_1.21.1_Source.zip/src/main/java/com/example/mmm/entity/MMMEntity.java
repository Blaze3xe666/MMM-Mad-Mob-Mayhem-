package com.example.mmm.entity;

import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.monster.Zombie;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

public class MMMEntity extends Zombie {
    private int pulseCooldown = 100;
    private int rageCooldown = 0;

    public MMMEntity(EntityType<? extends Zombie> type, Level level) {
        super(type, level);
        this.xpReward = 25;
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Zombie.createAttributes()
                .add(Attributes.MAX_HEALTH, 80.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.32D)
                .add(Attributes.ATTACK_DAMAGE, 9.0D)
                .add(Attributes.ARMOR, 8.0D)
                .add(Attributes.FOLLOW_RANGE, 32.0D)
                .add(Attributes.KNOCKBACK_RESISTANCE, 0.65D);
    }

    @Override
    public void tick() {
        super.tick();

        if (this.level().isClientSide || !this.isAlive()) {
            return;
        }

        if (pulseCooldown > 0) pulseCooldown--;
        if (rageCooldown > 0) rageCooldown--;

        // Special attack: a violet shockwave every ~8 seconds when a target is nearby.
        if (pulseCooldown <= 0 && this.getTarget() != null && this.distanceToSqr(this.getTarget()) < 100.0D) {
            shockwave();
            pulseCooldown = 160;
        }

        // Enrage below 50% health: brief speed boost, with a cooldown.
        if (this.getHealth() <= this.getMaxHealth() * 0.5F && rageCooldown <= 0) {
            this.addEffect(new net.minecraft.world.effect.MobEffectInstance(
                    net.minecraft.world.effect.MobEffects.MOVEMENT_SPEED, 100, 1));
            this.addEffect(new net.minecraft.world.effect.MobEffectInstance(
                    net.minecraft.world.effect.MobEffects.DAMAGE_BOOST, 100, 0));
            rageCooldown = 240;
        }
    }

    private void shockwave() {
        AABB area = this.getBoundingBox().inflate(3.5D, 1.5D, 3.5D);
        for (var target : this.level().getEntitiesOfClass(
                net.minecraft.world.entity.LivingEntity.class, area,
                entity -> entity != this && entity.isAlive() && this.canAttack(entity))) {
            target.hurt(this.damageSources().mobAttack(this), 7.0F);
            Vec3 push = target.position().subtract(this.position()).normalize().scale(1.25D);
            target.push(push.x, 0.45D, push.z);
            target.hurtMarked = true;
        }
    }

    @Override
    protected boolean shouldDropExperience() {
        return true;
    }
}

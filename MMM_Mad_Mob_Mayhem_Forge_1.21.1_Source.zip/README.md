# MMM — Mad Mob Mayhem

A small Minecraft Java Forge mod that adds **MMM-01, The Unhinged**, a hostile combat mob.

## Target
- Minecraft Java Edition **1.21.1**
- Minecraft Forge **52.0.28**
- Java **21**

Minecraft 1.20.1 is intentionally not targeted.

## Features
- 80 health, 9 attack damage, 8 armor, high knockback resistance.
- Uses the vanilla zombie model and texture as a stable placeholder.
- Shockwave attack: damages and knocks back nearby valid targets.
- Enrage below 50% health: temporary speed and damage boost.
- Spawn egg item with dark-purple and violet colors.
- 25 XP reward.

## Build
1. Install a JDK 21.
2. Install Gradle, or add the Gradle wrapper from the official Forge MDK for 1.21.1.
3. In this project folder, run `gradle build`.
4. The built mod jar should be in `build/libs/`.

To test in a development client, run `gradle runClient`.

## In game
- Find the spawn egg named **MMM Spawn Egg** in the creative inventory search.
- Or use: `/summon mmm:mmm_01`

## Notes
- This is a source project, not a precompiled or tested JAR. ForgeGradle may require internet access to download dependencies.
- The entity currently uses the vanilla zombie appearance as a placeholder. A custom model/texture can be added later.
- This first version does not add natural spawning; use the spawn egg or summon command.
